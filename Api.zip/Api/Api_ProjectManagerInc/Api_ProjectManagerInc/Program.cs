using System.Text;
using Business.Global;
using Business.Global.Contracts;
using Business.Login;
using Business.Login.Contracts;
using Business.Project;
using Business.Project.Contracts;
using Business.Report;
using Business.Report.Contracts;
using Business.Task;
using Business.Task.Contracts;
using DataAccess;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;

var builder = WebApplication.CreateBuilder(args);

// Variables JWT
var jwtSettings = builder.Configuration.GetSection("Jwt");
var key = Encoding.ASCII.GetBytes(jwtSettings["Key"]!);
// Variables JWT

// Configurar servicios de CORS
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAngularApp", builder =>
        builder.WithOrigins("http://localhost:4200")
               .AllowAnyMethod()
               .AllowAnyHeader()
               .AllowCredentials());
});
// Configurar servicios de CORS

builder.Services.AddControllers();

builder.Services.AddSingleton<DBContext>();

builder.Services.AddScoped<IErrorCode, ErrorCode>();
builder.Services.AddScoped<IErrorLog, ErrorLog>();

builder.Services.AddScoped<IDecrypter, Decrypter>();
builder.Services.AddScoped<IEncrypter, Encrypter>();
builder.Services.AddScoped<ITokenGenerator, TokenGenerator>();
builder.Services.AddScoped<IUserValidator, UserValidator>();

builder.Services.AddScoped<IProjectCreator, ProjectCreator>();
builder.Services.AddScoped<IProjectGetter, ProjectGetter>();

builder.Services.AddScoped<IReportGetter, ReportGetter>();

builder.Services.AddScoped<IStatusChanger, StatusChanger>();
builder.Services.AddScoped<ITaskGetter, TaskGetter>();

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

//JWT
// Configurar autenticaci�n JWT
builder.Services.AddAuthentication(options =>
{
    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;
})
.AddJwtBearer(options =>
{
    options.RequireHttpsMetadata = false;
    options.SaveToken = true;
    options.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuer = true,
        ValidateAudience = true,
        ValidateLifetime = true,
        ValidateIssuerSigningKey = true,
        ValidIssuer = jwtSettings["Issuer"],
        ValidAudience = jwtSettings["Audience"],
        IssuerSigningKey = new SymmetricSecurityKey(key),
        ClockSkew = TimeSpan.Zero // Opcional: elimina la tolerancia de tiempo
    };
});

builder.Services.AddAuthorization();
//JWT

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthentication();
app.UseAuthorization();

app.UseCors("AllowAngularApp");

app.MapControllers();

app.Run();
