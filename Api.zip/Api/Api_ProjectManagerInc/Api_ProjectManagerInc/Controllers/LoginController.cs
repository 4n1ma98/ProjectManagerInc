﻿using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Business.Login.Contracts;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Models;
using Models.dto;

namespace Api_ProjectManagerInc.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        private readonly ITokenGenerator _tokenGenerator;
        private readonly IUserValidator _userValidator;

        public LoginController(ITokenGenerator tokenGenerator ,IUserValidator userValidator)
        {
            _tokenGenerator = tokenGenerator;
            _userValidator = userValidator;
        }

        [HttpPost("[action]")]
        public IActionResult Login(CredentialRequest request)
        {
            if (string.IsNullOrEmpty(request.Email) || string.IsNullOrEmpty(request.Pass))
            {
                return BadRequest("Username and password required");
            }

            UserDTO? user = _userValidator.GetUser(request);

            if (user != null)
            {
                var token = _tokenGenerator.GenerateJwtToken(user);

                return Ok(token);
            }

            return Unauthorized("Error: Incorrect credentials");
        }
    }
}
