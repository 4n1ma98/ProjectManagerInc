﻿using Business.Project.Contracts;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Models;

namespace Api_ProjectManagerInc.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class ProjectController : ControllerBase
    {
        private readonly IProjectGetter _projectGetter;
        private readonly IProjectCreator _projectCreator;

        public ProjectController(IProjectGetter projectGetter, IProjectCreator projectCreator)
        {
            _projectGetter = projectGetter;
            _projectCreator = projectCreator;
        }

        [HttpGet("[action]")]
        public IActionResult GetList([FromQuery] int userId, int roleId)
        {
            Response response = _projectGetter.GetAll(userId, roleId);
            return response.IdError != 0 ? BadRequest(response) : Ok(response);
        }

        [HttpPost("[action]")]
        public IActionResult CreateNewProject(ProjectCreatorRequest request)
        {
            Response response = _projectCreator.Create(request.ProjectName, request.ProjectDescription, request.TaskName, request.UserId);
            return response.IdError != 0 ? BadRequest(response) : Ok(response);
        }
    }
}
