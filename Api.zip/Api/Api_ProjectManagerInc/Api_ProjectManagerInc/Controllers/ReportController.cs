﻿using Business.Report.Contracts;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Models;

namespace Api_ProjectManagerInc.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class ReportController : ControllerBase
    {
        private readonly IReportGetter _reportGetter;

        public ReportController(IReportGetter reportGetter) {
            _reportGetter = reportGetter;
        }

        [HttpGet("[action]")]
        public IActionResult GetReport([FromQuery] int userId, int roleId)
        {
            Response response = _reportGetter.GetReport(userId, roleId);
            return response.IdError != 0 ? BadRequest(response) : Ok(response);
        }
    }
}
