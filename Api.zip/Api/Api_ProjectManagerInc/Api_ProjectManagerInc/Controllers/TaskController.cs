﻿using Azure.Core;
using Business.Task.Contracts;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Models;

namespace Api_ProjectManagerInc.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class TaskController : ControllerBase
    {
        private readonly ITaskGetter _taskGetter;
        private readonly IStatusChanger _statusChanger;

        public TaskController(ITaskGetter taskGetter, IStatusChanger statusChanger)
        {
            _taskGetter = taskGetter;
            _statusChanger = statusChanger;
        }

        [HttpGet("[action]")]
        public IActionResult GetList([FromQuery] int userId, int projectId, int roleId)
        {
            Response response = _taskGetter.GetAll(projectId, userId, roleId);
            return response.IdError != 0 ? BadRequest(response) : Ok(response);
        }

        [HttpPost("[action]")]
        public IActionResult ChangeState(ChangeStateRequest request)
        {
            Response response = _statusChanger.Change(request.TaskId, request.TaskStateId);
            return response.IdError != 0 ? BadRequest(response) : Ok(response);

        }
    }
}
