﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Business.Global.Contracts;
using Business.Report.Contracts;
using Dapper;
using DataAccess;
using Microsoft.Extensions.Configuration;
using Models;
using Models.dto;

namespace Business.Report
{
    public class ReportGetter : IReportGetter
    {
        private readonly DBContext _dBContext;
        private readonly IConfiguration _config;
        private readonly IErrorCode _errorCode;
        private readonly IErrorLog _errorLog;

        public ReportGetter(DBContext dBContext, IConfiguration configuration, IErrorCode errorCode, IErrorLog errorLog)
        {
            _dBContext = dBContext;
            _config = configuration;
            _errorCode = errorCode;
            _errorLog = errorLog;
        }

        public Response GetReport(int userId, int roleId)
        {
            List<ReportDTO> report;

            var parameters = new
            {
                Option = 4,
                UserId = userId,
                RoleId = roleId
            };
            try
            {
                using (IDbConnection _context = _dBContext.Conn(_config.GetConnectionString("DefaultConnection")!))
                    report = _context.Query<ReportDTO>("SP_ProjectManagerInc", parameters, commandTimeout: 600, commandType: CommandType.StoredProcedure).ToList();

                return _errorCode.GetError(0, report);
            }
            catch (Exception ex)
            {
                _errorLog.Register("/ReportGetter/GetReport", ex.Message);
                return _errorCode.GetError(-999);
            }
        }
    }
}
