﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Business.Global.Contracts;
using Business.Task.Contracts;
using Dapper;
using DataAccess;
using Microsoft.Extensions.Configuration;
using Models;
using Models.dto;

namespace Business.Task
{
    public class TaskGetter : ITaskGetter
    {
        private readonly DBContext _dBContext;
        private readonly IConfiguration _config;
        private readonly IErrorCode _errorCode;
        private readonly IErrorLog _errorLog;

        public TaskGetter(DBContext dBContext, IConfiguration config, IErrorCode errorCode, IErrorLog errorLog)
        {
            _dBContext = dBContext;
            _config = config;
            _errorCode = errorCode;
            _errorLog = errorLog;
        }

        public Response GetAll(int projectId, int userId, int roleId)
        {
            List<TaskDTO> taskList;

            var parameters = new
            {
                Option = 2,
                ProjectId = projectId,
                UserId = userId,
                RoleId =roleId
            };

            try
            {
                using (IDbConnection _context = _dBContext.Conn(_config.GetConnectionString("DefaultConnection")!))
                    taskList = _context.Query<TaskDTO>("SP_ProjectManagerInc", parameters, commandTimeout: 600, commandType: CommandType.StoredProcedure).ToList();

                return _errorCode.GetError(0, taskList);
            }
            catch (Exception ex)
            {
                _errorLog.Register("/TaskGetter/GetAll", ex.Message);
                return _errorCode.GetError(-999);
            }
        }
    }
}
