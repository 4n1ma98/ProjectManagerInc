﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Business.Global.Contracts;
using Business.Task.Contracts;
using Dapper;
using DataAccess;
using Microsoft.Extensions.Configuration;
using Models;

namespace Business.Task
{
    public class StatusChanger : IStatusChanger
    {
        private readonly DBContext _dBContext;
        private readonly IConfiguration _config;
        private readonly IErrorCode _errorCode;
        private readonly IErrorLog _errorLog;

        public StatusChanger(DBContext dBContext, IConfiguration configuration, IErrorCode errorCode, IErrorLog errorLog)
        {
            _dBContext = dBContext;
            _config = configuration;
            _errorCode = errorCode;
            _errorLog = errorLog;
        }

        public Response Change(int taskId, int taskStateId)
        {
            var parameters = new
            {
                Option = 3,
                TaskId = taskId,
                TaskStateId = taskStateId
            };

            try
            {
                using (IDbConnection _context = _dBContext.Conn(_config.GetConnectionString("DefaultConnection")!))
                    _context.Execute("SP_ProjectManagerInc", parameters, commandTimeout: 600, commandType: CommandType.StoredProcedure);

                return _errorCode.GetError(0);
            }
            catch (Exception ex)
            {
                _errorLog.Register("/StatusChanger/Change", ex.Message);
                return _errorCode.GetError(-999);
            }
        }
    }
}
