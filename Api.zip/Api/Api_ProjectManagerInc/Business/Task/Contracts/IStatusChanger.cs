﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Models;

namespace Business.Task.Contracts
{
    public interface IStatusChanger
    {
        Response Change(int taskId, int taskStateId);
    }
}
