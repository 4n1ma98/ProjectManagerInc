﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Business.Global.Contracts;
using Business.Login.Contracts;
using Dapper;
using DataAccess;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using Models;
using Models.dto;

namespace Business.Login
{
    public class UserValidator : IUserValidator
    {
        private readonly DBContext _dBContext;
        private readonly IConfiguration _config;
        private readonly IEncrypter _encrypter;
        private readonly IErrorLog _errorLog;

        public UserValidator(DBContext dBContext,IConfiguration config, IEncrypter encrypter, IErrorLog errorLog)
        {
            _dBContext = dBContext;
            _config = config;
            _encrypter = encrypter;
            _errorLog = errorLog;
        }

        public UserDTO? GetUser(CredentialRequest request)
        {
            string sqlQuery = @"SELECT a.Id UserId, a.NombreCompleto FullName, b.Id RoleId, b.NombreRol RoleName
                                FROM TBL_Usuario a
                                INNER JOIN TBL_Rol b ON a.IdRol = b.Id
                                WHERE a.Correo = @Email AND a.Clave = @Pass AND b.Activo=1";

            var parameters = new
            {
                request.Email,
                Pass = _encrypter.Encrypt(request.Pass)
            };

            try
            {
                using (IDbConnection _context = _dBContext.Conn(_config.GetConnectionString("DefaultConnection")!))
                    return _context.Query<UserDTO>(sqlQuery, parameters).FirstOrDefault();
            }
            catch (Exception ex)
            {
                _errorLog.Register("/ProjectGetter/GetAll", ex.Message);
                return null;
            }
        }
    }
}
