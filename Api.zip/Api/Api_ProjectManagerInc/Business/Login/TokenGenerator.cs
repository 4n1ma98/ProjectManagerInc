﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Business.Global.Contracts;
using Business.Login.Contracts;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using Models;
using Models.dto;

namespace Business.Login
{
    public class TokenGenerator : ITokenGenerator
    {
        private readonly IConfiguration _config;
        private readonly IErrorLog _errorLog;

        public TokenGenerator(IConfiguration config, IErrorLog errorLog)
        {
            _config = config;
            _errorLog = errorLog;
        }

        public LoginResponse? GenerateJwtToken(UserDTO user)
        {
            try
            {
                var hoy = DateTime.UtcNow;
                var jwtSettings = _config.GetSection("Jwt");
                var key = Encoding.ASCII.GetBytes(jwtSettings["Key"]!);
                var tokenExpiryTimeStamp = hoy.AddMinutes(double.Parse(jwtSettings["ExpireMinutes"]!));

                var tokenDescriptor = new SecurityTokenDescriptor
                {
                    Subject = new ClaimsIdentity(
                    [
                        new Claim(ClaimTypes.Name, user.FullName)
                    ]),
                    Expires = tokenExpiryTimeStamp,
                    Issuer = jwtSettings["Issuer"],
                    Audience = jwtSettings["Audience"],
                    SigningCredentials = new SigningCredentials(
                        new SymmetricSecurityKey(key),
                        SecurityAlgorithms.HmacSha256Signature)
                };

                var tokenHandler = new JwtSecurityTokenHandler();
                var createdToken = tokenHandler.CreateToken(tokenDescriptor);
                var accessToken = tokenHandler.WriteToken(createdToken);

                return new LoginResponse
                {
                    User = user,
                    AccessToken = accessToken,
                    ExpiredIn = (int)tokenExpiryTimeStamp.Subtract(hoy).TotalSeconds
                };
            }
            catch (Exception ex)
            {
                _errorLog.Register("/TokenGenerator/GenerateJwtToken", ex.Message);
                return null;
            }
        }
    }
}
