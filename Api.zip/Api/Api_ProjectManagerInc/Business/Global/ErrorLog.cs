﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Business.Global.Contracts;
using Dapper;
using DataAccess;
using Microsoft.Extensions.Configuration;

namespace Business.Global
{
    public class ErrorLog : IErrorLog
    {
		private readonly DBContext _dBContext;
		private readonly IConfiguration _config;

		public ErrorLog(DBContext dBContext, IConfiguration config)
		{
			_dBContext = dBContext;
			_config = config;
		}

        public void Register(string method, string error)
        {
			string sqlQuery = "INSERT INTO TBL_ErrorLog VALUES(@Metodo, @Error, GETDATE());";
			var parameters = new
			{
				Metodo = "Api_ProjectManagerInc" + method,
				Error = error
			};

			try
			{
				using (IDbConnection _context = _dBContext.Conn(_config.GetConnectionString("DefaultConnection")!))
					_context.Execute(sqlQuery, parameters, commandTimeout: 600);
			}
			catch (Exception)
			{
                Console.WriteLine("Error");
			}
        }
    }
}
