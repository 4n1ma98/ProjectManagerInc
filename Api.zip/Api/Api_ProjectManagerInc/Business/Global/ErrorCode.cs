﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Business.Global.Contracts;
using Models;

namespace Business.Global
{
    public class ErrorCode : IErrorCode
    {
        public Response GetError(int idError, object? additionalData = null)
        {
            Response response = new() { IdError = idError, AdditionalData = additionalData };

            if (idError == 0) response.Message = "Proceso exitoso";
            else if (idError == -999) response.Message = "Error, contacte con el administrador";

            return response;
        }
    }
}
