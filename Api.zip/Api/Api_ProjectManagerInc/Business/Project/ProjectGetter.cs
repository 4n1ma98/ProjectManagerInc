﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Business.Global.Contracts;
using Business.Project.Contracts;
using Dapper;
using DataAccess;
using Microsoft.Extensions.Configuration;
using Models;
using Models.dto;

namespace Business.Project
{
    public class ProjectGetter : IProjectGetter
    {
        private readonly DBContext _dBContext;
        private readonly IConfiguration _config;
        private readonly IErrorCode _errorCode;
        private readonly IErrorLog _errorLog;

        public ProjectGetter(DBContext dBContext, IConfiguration configuration, IErrorCode errorCode, IErrorLog errorLog)
        {
            _dBContext = dBContext;
            _config = configuration;
            _errorCode = errorCode;
            _errorLog = errorLog;
        }

        public Response GetAll(int userId, int roleId)
        {
            List<ProjectDTO> projectList;

            var parameters = new
            {
                Option = 1,
                UserId = userId,
                RoleId = roleId
            };

            try
            {
                using (IDbConnection _context = _dBContext.Conn(_config.GetConnectionString("DefaultConnection")!))
                    projectList = _context.Query<ProjectDTO>("SP_ProjectManagerInc", parameters, commandTimeout: 600, commandType: CommandType.StoredProcedure).ToList();

                return _errorCode.GetError(0, projectList);
            }
            catch (Exception ex)
            {
                _errorLog.Register("/ProjectGetter/GetAll", ex.Message);
                return _errorCode.GetError(-999);
            }
        }
    }
}
