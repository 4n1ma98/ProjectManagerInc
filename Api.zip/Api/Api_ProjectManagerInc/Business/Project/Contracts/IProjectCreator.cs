﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Models;

namespace Business.Project.Contracts
{
    public interface IProjectCreator
    {
        Response Create(string projectName, string projectDescription, string taskName, int userId);
    }
}
