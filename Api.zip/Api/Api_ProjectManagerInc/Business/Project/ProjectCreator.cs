﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Business.Global.Contracts;
using Business.Project.Contracts;
using Dapper;
using DataAccess;
using Microsoft.Extensions.Configuration;
using Models;
using Models.dto;

namespace Business.Project
{
    public class ProjectCreator : IProjectCreator
    {
        private readonly DBContext _dBContext;
        private readonly IConfiguration _config;
        private readonly IErrorCode _errorCode;
        private readonly IErrorLog _errorLog;

        public ProjectCreator(DBContext dBContext, IConfiguration configuration, IErrorCode errorCode, IErrorLog errorLog)
        {
            _dBContext = dBContext;
            _config = configuration;
            _errorCode = errorCode;
            _errorLog = errorLog;
        }

        public Response Create(string projectName, string projectDescription, string taskName, int userId)
        {
            var parameters = new
            {
                Option = 5,
                ProjectName = projectName,
                ProjectDescription = projectDescription,
                TaskName = taskName,
                UserId = userId
            };

            try
            {
                using (IDbConnection _context = _dBContext.Conn(_config.GetConnectionString("DefaultConnection")!))
                    _context.Execute("SP_ProjectManagerInc", parameters, commandTimeout: 600, commandType: CommandType.StoredProcedure);

                return _errorCode.GetError(0);
            }
            catch (Exception ex)
            {
                _errorLog.Register("/ProjectCreator/Create", ex.Message);
                return _errorCode.GetError(-999);
            }
        }
    }
}
