﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Models.dto;

namespace Models
{
    public class Response
    {
        public int IdError { get; set; }
        public string Message { get; set; } = default!;
        public object? AdditionalData { get; set; } = null;
    }

    public class LoginResponse
    {
        public UserDTO User { get; set; } = default!;
        public string? AccessToken { get; set; }
        public int ExpiredIn {  get; set; }
    }
}
