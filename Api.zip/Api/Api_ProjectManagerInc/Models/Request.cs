﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models
{
    public class CredentialRequest
    {
        public string Email { get; set; } = default!;
        public string Pass { get; set; } = default!;
    }

    public class ChangeStateRequest()
    {
        public int TaskId { get; set; }
        public int TaskStateId { get; set; }
    }

    public class ProjectCreatorRequest
    {
        public string ProjectName { get; set; } = default!;
        public string ProjectDescription { get; set; } = default!;
        public string TaskName { get; set; } = default!;
        public int UserId { get; set; }
    }
}
